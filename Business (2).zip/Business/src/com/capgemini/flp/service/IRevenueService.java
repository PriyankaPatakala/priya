package com.capgemini.flp.service;

import java.util.List;

import com.capgemini.flp.entity.Revenue;
import com.capgemini.flp.exception.RevenueException;


public interface IRevenueService {
	/*public List<Revenue> getBusinessdetails();*/
	Revenue findProductSold(String merchant_email_Id) ;
	
	//public Double findTotalRevenue();
	
	
	
	
}
