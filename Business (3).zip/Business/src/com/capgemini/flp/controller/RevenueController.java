package com.capgemini.flp.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.capgemini.flp.entity.Revenue;
import com.capgemini.flp.service.IRevenueService;

@Controller
public class RevenueController {
	@Autowired
	IRevenueService service;
 
	@RequestMapping(value="/homepage",method=RequestMethod.GET)
	public ModelAndView displaypage(){
	Revenue rev = new Revenue();
	return new ModelAndView("solddetails","revnue",rev);
	}
	
	@RequestMapping(value="/revenuepage",method=RequestMethod.POST)
	public ModelAndView answer(@RequestParam("merchant_email_Id") String email) {
	Revenue mail= (Revenue) service.findProductSold(email);
	return new ModelAndView("success","list",mail);
	}
	

	@RequestMapping(value="/totalamount",method=RequestMethod.GET)
	public ModelAndView total(@RequestParam("email") String email) {
	Revenue rev= (Revenue) service.findProductSold(email);
	return new ModelAndView("revenuedetails","amount",rev);
		
}
	
	
	}
	

