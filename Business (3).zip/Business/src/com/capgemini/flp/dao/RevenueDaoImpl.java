package com.capgemini.flp.dao;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.capgemini.flp.entity.Revenue;


@Repository
@Transactional

public class RevenueDaoImpl implements IRevenueDao{
	@PersistenceContext
	EntityManager em;
	Revenue rev = new Revenue();
	
	public Revenue findProductSold(String merchant_email_Id) {		
		 TypedQuery<Revenue> query=em.createQuery("select rev from Revenue rev where rev.merchant_email_Id=?",Revenue.class);
			query.setParameter(1,merchant_email_Id);
			rev = query.getSingleResult();
			double rev1= (double)rev.getNumberOfProductSold() * rev.getSellingCost();
			rev.setRevenue(rev1);
			if(rev.getSellingCost()>rev.getProduct_Price())
			{
			double pro=(((rev.getSellingCost()-rev.getProduct_Price())/rev.getProduct_Price())*100);
			rev.setProfit(pro);
			}
			else
			{
				double loss=(((rev.getProduct_Price()-rev.getSellingCost())/rev.getProduct_Price())*100);
				rev.setLoss(loss);
			}
			em.persist(rev);
			return rev;	
	
	}}

