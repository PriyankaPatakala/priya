package com.capgemini.flp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.flp.dao.IRevenueDao;
import com.capgemini.flp.entity.Revenue;
@Service
public class RevnueServiceImpl implements IRevenueService{
	
	@Autowired
	IRevenueDao dao;
	@Override
	
	public Revenue findProductSold(String merchant_email_Id) {
		return dao.findProductSold(merchant_email_Id);
	}
	
	
}
